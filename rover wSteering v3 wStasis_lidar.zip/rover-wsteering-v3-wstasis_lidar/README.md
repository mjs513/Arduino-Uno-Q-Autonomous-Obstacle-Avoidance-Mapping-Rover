# 😀 joystick brick

Original main.py was changed to address structual changes to the api


1. Fix Dictionary State Formats: The backend keys for axes and buttons in state return structured sub-dictionaries where the event codes are string keys (e.g., {"0": 128, "1": 0}). The old loop expects state["axes"] and state["buttons"] to be array-indexed lists, which causes it to crash. We must convert these back into array-indexed structures before the loop uses axis_index and button_index.

2. Handle Connection Status Error Handshakes: Avoid crashes when getState() drops connection by gracefully checking for an error status block.

3. Resolve Global Key Assignments: Clean up the loose references to uninitialized variables like spidev_enable (which was causing a NameError) and ensure your global metadata variables are appropriately scoped.


# July 13, 2026
Add fuzz and flat capabilities for joysticks.  From Gemini
In the context of Linux **evdev** (Event Device) and joystick calibration, **flat** and **fuzz** are hardware parameters used to filter out noise from raw analog sensors before that data reaches your application.

Analog joysticks rely on potentiometers or Hall-effect sensors that are highly sensitive, physically imperfect, and rarely sit perfectly still. `fuzz` and `flat` act as your controller's built-in stabilizers.

---

### 1. Flat (The Deadzone)

`flat` defines the **size of the center deadzone**.

* **What it does:** It tells the operating system to treat any minor raw values near the center position as an absolute zero.
* **Why it matters:** When you let go of an analog stick, it rarely returns perfectly to its mathematical center because of mechanical spring wear. Instead of resting at exactly `128` (on a 0–255 scale), it might rest at `131` or `125`.
* **The Result:** If `flat = 15`, any value within 15 units of the center is snapped to 0. Without a `flat` value, your robot or game character would slowly drift or crawl even when you aren't touching the stick.

```
       [--- Deadzone (Flat) ---]
<-------|-------------------|------->  Analog Stick Axis Range
     -15 units   0   +15 units
  (Minor stick wobble here is ignored)

```

### 2. Fuzz (The Noise Filter)

`fuzz` defines a **noise filter or smoothing threshold** for live movement.

* **What it does:** It dictates how much a stick's position must change before the operating system bothers to register it as a brand-new movement event.
* **Why it matters:** Electrical interference and micro-vibrations cause analog sensors to fluctuate constantly. If you hold a stick perfectly still at a halfway point, the raw values might rapidly flicker back and forth (e.g., `180, 181, 180, 179, 180`).
* **The Result:** If `fuzz = 2`, the OS will filter out any tiny jitter that changes by less than 2 units. It will only emit a new event if you move the stick far enough to cross that threshold, drastically saving CPU processing time by ignoring electrical "noise."

### Summary Checklist

| Parameter | Purpose | Main Benefit |
| --- | --- | --- |
| **`flat`** | Creates a deadzone around the center point. | Stops **stick drift** when idle. |
| **`fuzz`** | Filters out tiny, continuous fluctuations. | Stops **input jittering** during active use. |